Установка:

```
sh -c "$(wget --no-check-certificate -qO - https://raw.githubusercontent.com/Tombraider2006/K1/main/shape/installer.sh)"
```